﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYNKROAPP.CLASES
{
    public class ProducteDetallJson
    {
        public ProducteGeneral Producte { get; set; }
        public DetallProducte Detall { get; set; }
    }

}
